import { AppNav } from '@/components/app/app-nav'
import { CompanionChat } from '@/components/app/companion-chat'

export const metadata = {
  title: 'Вечерний план — Напарник',
}

export default function PlanPage() {
  return (
    <main className="flex h-dvh flex-col">
      <header className="border-b border-border px-4 py-3">
        <div className="mx-auto flex max-w-md flex-col">
          <h1 className="text-sm font-bold">Вечерний план</h1>
          <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
            3 минуты — и завтра начнётся само
          </p>
        </div>
      </header>
      <div className="min-h-0 flex-1">
        <CompanionChat
          mode="plan"
          greeting="Йо. Давай разберём завтра, пока оно не превратилось в хаос. Назови 1–3 дела, которые реально важны. Не десять. Одно — тоже норм."
          placeholder="Например: доделать презентацию…"
        />
      </div>
      <AppNav />
    </main>
  )
}
