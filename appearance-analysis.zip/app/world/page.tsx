import Image from 'next/image'
import { AppNav } from '@/components/app/app-nav'

export const metadata = {
  title: 'Мир напарника — Напарник',
}

const milestones = [
  { name: 'Костёр', desc: 'Первая сессия. С него всё началось.', unlocked: true },
  { name: 'Палатка', desc: '5 сессий — напарнику есть где жить.', unlocked: true },
  { name: 'Светящийся сад', desc: '15 сессий — остров зеленеет.', unlocked: true },
  { name: 'Маяк', desc: '30 сессий — виден издалека.', unlocked: false },
  { name: 'Причал', desc: '50 сессий — к острову можно приплыть.', unlocked: false },
]

export default function WorldPage() {
  return (
    <main className="flex min-h-dvh flex-col pb-24">
      <header className="border-b border-border px-4 py-3">
        <div className="mx-auto flex max-w-md flex-col">
          <h1 className="text-sm font-bold">Мир напарника</h1>
          <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
            растёт от сессий — не откатывается никогда
          </p>
        </div>
      </header>

      <div className="mx-auto flex w-full max-w-md flex-col gap-6 px-4 py-6">
        <div className="relative aspect-[4/3] w-full overflow-hidden rounded-3xl">
          <Image
            src="/images/naparnik-world.png"
            alt="Остров напарника: костёр, палатка и светящийся сад"
            fill
            sizes="(max-width: 768px) 100vw, 448px"
            className="object-cover"
            priority
          />
          <div className="absolute inset-x-0 bottom-0 flex items-baseline justify-between bg-gradient-to-t from-background/90 to-transparent p-4">
            <span className="text-2xl font-bold">17 сессий</span>
            <span className="font-mono text-xs text-primary">3 из 5 построек</span>
          </div>
        </div>

        <div className="rounded-2xl border border-primary/30 bg-card p-4 text-sm leading-relaxed">
          <span className="font-bold">Правило острова: </span>
          <span className="text-muted-foreground">
            здесь ничего не сгорает и не рушится. Пропустил неделю? Остров ждёт.
            Провал — это ноль, не минус.
          </span>
        </div>

        <ul className="flex flex-col gap-3">
          {milestones.map((m) => (
            <li
              key={m.name}
              className={`flex items-start gap-3 rounded-xl border p-4 ${
                m.unlocked ? 'border-border bg-card' : 'border-border/50 bg-transparent opacity-60'
              }`}
            >
              <span
                aria-hidden="true"
                className={`mt-0.5 font-mono text-sm ${m.unlocked ? 'text-primary' : 'text-muted-foreground'}`}
              >
                {m.unlocked ? '✓' : '···'}
              </span>
              <div className="flex flex-col gap-0.5">
                <span className="text-sm font-bold">{m.name}</span>
                <span className="text-sm leading-relaxed text-muted-foreground">{m.desc}</span>
              </div>
            </li>
          ))}
        </ul>
      </div>
      <AppNav />
    </main>
  )
}
