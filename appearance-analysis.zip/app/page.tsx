import { SiteHeader } from '@/components/landing/site-header'
import { Hero } from '@/components/landing/hero'
import { Problem } from '@/components/landing/problem'
import { HowItWorks } from '@/components/landing/how-it-works'
import { WorldSection } from '@/components/landing/world-section'
import { Pricing } from '@/components/landing/pricing'
import { Footer } from '@/components/landing/footer'

export default function Page() {
  return (
    <>
      <SiteHeader />
      <main>
        <Hero />
        <Problem />
        <HowItWorks />
        <WorldSection />
        <Pricing />
      </main>
      <Footer />
    </>
  )
}
