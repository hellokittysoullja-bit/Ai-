import { AppNav } from '@/components/app/app-nav'
import { FocusSession } from '@/components/app/focus-session'

export const metadata = {
  title: 'Фокус-сессия — Напарник',
}

export default function FocusPage() {
  return (
    <main className="flex min-h-dvh flex-col pb-20">
      <header className="border-b border-border px-4 py-3">
        <div className="mx-auto flex max-w-md flex-col">
          <h1 className="text-sm font-bold">Фокус-сессия</h1>
          <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
            body doubling — работаем вдвоём
          </p>
        </div>
      </header>
      <FocusSession />
      <AppNav />
    </main>
  )
}
